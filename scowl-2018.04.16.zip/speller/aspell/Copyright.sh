cat <<EOF
This English word list is comes directly from SCOWL $SCOWL_VERSION (up to level 60,
using the speller/make-aspell-dict script, http://wordlist.sourceforge.net/) 
and is thus under the same copyright of SCOWL.  The affix file (only
included in the aspell6 package) is based on the Ispell one which is
under the same copyright of Ispell.  Part of SCOWL is also based on
Ispell thus the Ispell copyright is included with the SCOWL copyright.
EOF
